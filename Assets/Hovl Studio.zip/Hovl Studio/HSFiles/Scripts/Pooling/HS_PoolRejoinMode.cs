using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CGT.Pooling
{
    public enum HS_PoolRejoinMode
    {
        Manual,
        Auto,
    }
}